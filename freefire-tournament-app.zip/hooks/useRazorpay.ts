"use client"

import { useState } from "react"
import { loadRazorpayScript, RAZORPAY_CONFIG, type RazorpayOptions } from "@/lib/razorpay"
import { useAuth } from "@/contexts/AuthContext"
import toast from "react-hot-toast"

declare global {
  interface Window {
    Razorpay: any
  }
}

export const useRazorpay = () => {
  const [loading, setLoading] = useState(false)
  const { currentUser } = useAuth()

  const processPayment = async (tournamentId: string, amount: number, tournamentName: string) => {
    if (!currentUser) {
      toast.error("Please login to join tournaments")
      return false
    }

    setLoading(true)

    try {
      // Load Razorpay script
      const scriptLoaded = await loadRazorpayScript()
      if (!scriptLoaded) {
        toast.error("Failed to load payment gateway")
        return false
      }

      // Create order
      const orderResponse = await fetch("/api/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount,
          tournamentId,
          userId: currentUser.uid,
        }),
      })

      const orderData = await orderResponse.json()

      if (!orderData.success) {
        toast.error("Failed to create payment order")
        return false
      }

      // Configure Razorpay options
      const options: RazorpayOptions = {
        key: RAZORPAY_CONFIG.key_id,
        amount: orderData.order.amount,
        currency: "INR",
        name: "Free Fire Tournament",
        description: `Entry fee for ${tournamentName}`,
        order_id: orderData.order.id,
        handler: async (response: any) => {
          try {
            // Verify payment
            const verifyResponse = await fetch("/api/verify-payment", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_order_id: response.razorpay_order_id,
                razorpay_signature: response.razorpay_signature,
                tournamentId,
                userId: currentUser.uid,
                amount,
              }),
            })

            const verifyData = await verifyResponse.json()

            if (verifyData.success) {
              toast.success("Payment successful! You have joined the tournament.")
              // Refresh the page or update state to reflect the change
              window.location.reload()
            } else {
              toast.error("Payment verification failed")
            }
          } catch (error) {
            console.error("Payment verification error:", error)
            toast.error("Payment verification failed")
          }
        },
        prefill: {
          name: currentUser.displayName,
          email: currentUser.email,
          contact: currentUser.phoneNumber || "",
        },
        theme: {
          color: "#8b5cf6", // Purple theme to match the app
        },
      }

      // Open Razorpay checkout
      const razorpay = new window.Razorpay(options)
      razorpay.on("payment.failed", (response: any) => {
        toast.error(`Payment failed: ${response.error.description}`)
      })

      razorpay.open()
      return true
    } catch (error) {
      console.error("Payment processing error:", error)
      toast.error("Failed to process payment")
      return false
    } finally {
      setLoading(false)
    }
  }

  return {
    processPayment,
    loading,
  }
}
