"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, Clock } from "lucide-react"
import Link from "next/link"

interface PaymentStatusProps {
  status: "success" | "failed" | "pending"
  tournamentName?: string
  amount?: number
  onClose?: () => void
}

export default function PaymentStatus({ status, tournamentName, amount, onClose }: PaymentStatusProps) {
  const [countdown, setCountdown] = useState(5)

  useEffect(() => {
    if (status === "success") {
      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer)
            if (onClose) onClose()
            return 0
          }
          return prev - 1
        })
      }, 1000)

      return () => clearInterval(timer)
    }
  }, [status, onClose])

  const getStatusIcon = () => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
      case "failed":
        return <XCircle className="h-16 w-16 text-red-500 mx-auto" />
      case "pending":
        return <Clock className="h-16 w-16 text-yellow-500 mx-auto animate-pulse" />
    }
  }

  const getStatusMessage = () => {
    switch (status) {
      case "success":
        return {
          title: "Payment Successful!",
          description: `You have successfully joined ${tournamentName}. You will be redirected to your dashboard in ${countdown} seconds.`,
        }
      case "failed":
        return {
          title: "Payment Failed",
          description:
            "Your payment could not be processed. Please try again or contact support if the issue persists.",
        }
      case "pending":
        return {
          title: "Processing Payment",
          description: "Please wait while we process your payment. Do not close this window.",
        }
    }
  }

  const statusInfo = getStatusMessage()

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="bg-slate-800 border-slate-700 max-w-md w-full">
        <CardHeader className="text-center">
          {getStatusIcon()}
          <CardTitle className="text-white text-2xl mt-4">{statusInfo.title}</CardTitle>
          <CardDescription className="text-gray-400">{statusInfo.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {amount && (
            <div className="bg-slate-700/50 rounded-lg p-3 text-center">
              <p className="text-gray-300">Amount: ₹{amount}</p>
              {tournamentName && <p className="text-gray-300">Tournament: {tournamentName}</p>}
            </div>
          )}

          <div className="flex gap-2">
            {status === "success" && (
              <Link href="/user" className="flex-1">
                <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  Go to Dashboard
                </Button>
              </Link>
            )}
            {status === "failed" && (
              <Button
                onClick={onClose}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                Try Again
              </Button>
            )}
            {status !== "pending" && (
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1 border-slate-600 text-gray-300 hover:bg-slate-700 bg-transparent"
              >
                Close
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
