"use client"

import { useState, useEffect } from "react"
import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Users } from "lucide-react"
import type { Tournament, User } from "@/types"

interface ViewPlayersDialogProps {
  tournament: Tournament
  onClose: () => void
}

interface PlayerData {
  user: User
  joinedAt: Date
}

export default function ViewPlayersDialog({ tournament }: ViewPlayersDialogProps) {
  const [players, setPlayers] = useState<PlayerData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchPlayers = async () => {
      try {
        const playersData: PlayerData[] = []

        // Get user tournament records for this tournament
        const userTournamentsQuery = query(
          collection(db, "userTournaments"),
          where("tournamentId", "==", tournament.id),
        )
        const userTournamentsSnapshot = await getDocs(userTournamentsQuery)

        // Fetch user details for each registered player
        for (const userTournamentDoc of userTournamentsSnapshot.docs) {
          const userTournamentData = userTournamentDoc.data()
          const userDoc = await getDoc(doc(db, "users", userTournamentData.userId))

          if (userDoc.exists()) {
            playersData.push({
              user: userDoc.data() as User,
              joinedAt: userTournamentData.joinedAt.toDate(),
            })
          }
        }

        setPlayers(playersData)
      } catch (error) {
        console.error("Error fetching players:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchPlayers()
  }, [tournament.id])

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">{tournament.name}</h3>
          <p className="text-gray-400">
            {players.length} / {tournament.maxPlayers} players registered
          </p>
        </div>
        <Badge className="bg-blue-600 hover:bg-blue-700">
          <Users className="mr-1 h-3 w-3" />
          {players.length} Players
        </Badge>
      </div>

      {players.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <Users className="mx-auto h-12 w-12 mb-4 opacity-50" />
          <p>No players registered yet.</p>
        </div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow className="border-slate-700">
              <TableHead className="text-gray-300">Player Name</TableHead>
              <TableHead className="text-gray-300">Email</TableHead>
              <TableHead className="text-gray-300">Free Fire ID</TableHead>
              <TableHead className="text-gray-300">Joined At</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {players.map((playerData, index) => (
              <TableRow key={index} className="border-slate-700">
                <TableCell className="text-white font-medium">{playerData.user.displayName}</TableCell>
                <TableCell className="text-gray-300">{playerData.user.email}</TableCell>
                <TableCell className="text-gray-300">{playerData.user.freeFireId || "Not provided"}</TableCell>
                <TableCell className="text-gray-300">
                  {playerData.joinedAt.toLocaleDateString()} {playerData.joinedAt.toLocaleTimeString()}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  )
}
