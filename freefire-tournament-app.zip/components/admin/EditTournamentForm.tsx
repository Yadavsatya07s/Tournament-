"use client"

import type React from "react"

import { useState } from "react"
import { useTournaments } from "@/contexts/TournamentContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { format } from "date-fns"
import type { Tournament } from "@/types"

interface EditTournamentFormProps {
  tournament: Tournament
  onClose: () => void
}

export default function EditTournamentForm({ tournament, onClose }: EditTournamentFormProps) {
  const { updateTournament } = useTournaments()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: tournament.name,
    date: format(tournament.date, "yyyy-MM-dd"),
    time: format(tournament.date, "HH:mm"),
    entryFee: tournament.entryFee.toString(),
    maxPlayers: tournament.maxPlayers.toString(),
    prizePool: tournament.prizePool.toString(),
    roomId: tournament.roomId,
    roomPassword: tournament.roomPassword,
    status: tournament.status,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const updates = {
        name: formData.name,
        date: new Date(`${formData.date}T${formData.time}`),
        entryFee: Number(formData.entryFee),
        maxPlayers: Number(formData.maxPlayers),
        prizePool: Number(formData.prizePool),
        roomId: formData.roomId,
        roomPassword: formData.roomPassword,
        status: formData.status,
      }

      await updateTournament(tournament.id, updates)
      onClose()
    } catch (error) {
      console.error("Error updating tournament:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name" className="text-gray-300">
            Tournament Name
          </Label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="entryFee" className="text-gray-300">
            Entry Fee (₹)
          </Label>
          <Input
            id="entryFee"
            name="entryFee"
            type="number"
            value={formData.entryFee}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="date" className="text-gray-300">
            Date
          </Label>
          <Input
            id="date"
            name="date"
            type="date"
            value={formData.date}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="time" className="text-gray-300">
            Time
          </Label>
          <Input
            id="time"
            name="time"
            type="time"
            value={formData.time}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="maxPlayers" className="text-gray-300">
            Max Players
          </Label>
          <Input
            id="maxPlayers"
            name="maxPlayers"
            type="number"
            value={formData.maxPlayers}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="prizePool" className="text-gray-300">
            Prize Pool (₹)
          </Label>
          <Input
            id="prizePool"
            name="prizePool"
            type="number"
            value={formData.prizePool}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="roomId" className="text-gray-300">
            Room ID
          </Label>
          <Input
            id="roomId"
            name="roomId"
            value={formData.roomId}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="roomPassword" className="text-gray-300">
            Room Password
          </Label>
          <Input
            id="roomPassword"
            name="roomPassword"
            value={formData.roomPassword}
            onChange={handleChange}
            className="bg-slate-700/50 border-slate-600 text-white"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="status" className="text-gray-300">
          Status
        </Label>
        <Select
          value={formData.status}
          onValueChange={(value) => setFormData({ ...formData, status: value as Tournament["status"] })}
        >
          <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-700">
            <SelectItem value="upcoming" className="text-white focus:bg-slate-700">
              Upcoming
            </SelectItem>
            <SelectItem value="ongoing" className="text-white focus:bg-slate-700">
              Ongoing
            </SelectItem>
            <SelectItem value="completed" className="text-white focus:bg-slate-700">
              Completed
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onClose}
          className="border-slate-600 text-gray-300 bg-transparent"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={loading}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          {loading ? "Updating..." : "Update Tournament"}
        </Button>
      </div>
    </form>
  )
}
