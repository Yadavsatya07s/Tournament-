"use client"

import { useState } from "react"
import { useTournaments } from "@/contexts/TournamentContext"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Trophy, Plus, Save } from "lucide-react"
import type { Tournament, TournamentResult } from "@/types"

interface TournamentResultsProps {
  tournament: Tournament
  onClose: () => void
}

export default function TournamentResults({ tournament, onClose }: TournamentResultsProps) {
  const { updateTournament } = useTournaments()
  const [results, setResults] = useState<TournamentResult[]>(
    tournament.results || [
      { position: 1, playerName: "", playerId: "", prize: 0 },
      { position: 2, playerName: "", playerId: "", prize: 0 },
      { position: 3, playerName: "", playerId: "", prize: 0 },
    ],
  )
  const [loading, setLoading] = useState(false)

  const addResult = () => {
    setResults([
      ...results,
      {
        position: results.length + 1,
        playerName: "",
        playerId: "",
        prize: 0,
      },
    ])
  }

  const updateResult = (index: number, field: keyof TournamentResult, value: string | number) => {
    const updatedResults = [...results]
    updatedResults[index] = { ...updatedResults[index], [field]: value }
    setResults(updatedResults)
  }

  const removeResult = (index: number) => {
    setResults(results.filter((_, i) => i !== index))
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      await updateTournament(tournament.id, {
        results: results.filter((r) => r.playerName.trim() !== ""),
        status: "completed",
      })
      onClose()
    } catch (error) {
      console.error("Error saving results:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold text-white">{tournament.name} - Results</h3>
          <p className="text-gray-400">Add tournament results and prize distribution</p>
        </div>
        <Button
          onClick={addResult}
          size="sm"
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Position
        </Button>
      </div>

      <Card className="bg-slate-700/50 border-slate-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Trophy className="mr-2 h-5 w-5 text-yellow-500" />
            Tournament Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-slate-600">
                <TableHead className="text-gray-300">Position</TableHead>
                <TableHead className="text-gray-300">Player Name</TableHead>
                <TableHead className="text-gray-300">Player ID</TableHead>
                <TableHead className="text-gray-300">Prize (₹)</TableHead>
                <TableHead className="text-gray-300">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.map((result, index) => (
                <TableRow key={index} className="border-slate-600">
                  <TableCell className="text-white font-bold">#{result.position}</TableCell>
                  <TableCell>
                    <Input
                      value={result.playerName}
                      onChange={(e) => updateResult(index, "playerName", e.target.value)}
                      placeholder="Enter player name"
                      className="bg-slate-600 border-slate-500 text-white"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      value={result.playerId}
                      onChange={(e) => updateResult(index, "playerId", e.target.value)}
                      placeholder="Enter player ID"
                      className="bg-slate-600 border-slate-500 text-white"
                    />
                  </TableCell>
                  <TableCell>
                    <Input
                      type="number"
                      value={result.prize}
                      onChange={(e) => updateResult(index, "prize", Number(e.target.value))}
                      placeholder="Prize amount"
                      className="bg-slate-600 border-slate-500 text-white"
                    />
                  </TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => removeResult(index)}
                      className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                    >
                      Remove
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="flex justify-end space-x-2">
        <Button variant="outline" onClick={onClose} className="border-slate-600 text-gray-300 bg-transparent">
          Cancel
        </Button>
        <Button
          onClick={handleSave}
          disabled={loading}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          <Save className="h-4 w-4 mr-2" />
          {loading ? "Saving..." : "Save Results"}
        </Button>
      </div>
    </div>
  )
}
