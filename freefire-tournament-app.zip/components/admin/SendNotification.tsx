"use client"

import type React from "react"

import { useState } from "react"
import { collection, addDoc, query, getDocs } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Send } from "lucide-react"
import toast from "react-hot-toast"
import type { Tournament } from "@/types"

interface SendNotificationProps {
  tournaments: Tournament[]
  onClose: () => void
}

export default function SendNotification({ tournaments, onClose }: SendNotificationProps) {
  const [formData, setFormData] = useState({
    title: "",
    message: "",
    type: "info" as "info" | "success" | "warning" | "error",
    target: "all" as "all" | "tournament",
    tournamentId: "",
  })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.title || !formData.message) return

    setLoading(true)
    try {
      let targetUsers: string[] = []

      if (formData.target === "all") {
        // Get all users
        const usersQuery = query(collection(db, "users"))
        const usersSnapshot = await getDocs(usersQuery)
        targetUsers = usersSnapshot.docs.map((doc) => doc.id)
      } else if (formData.target === "tournament" && formData.tournamentId) {
        // Get users registered for specific tournament
        const tournament = tournaments.find((t) => t.id === formData.tournamentId)
        if (tournament) {
          targetUsers = tournament.registeredPlayers
        }
      }

      // Send notification to each target user
      const notifications = targetUsers.map((userId) => ({
        userId,
        title: formData.title,
        message: formData.message,
        type: formData.type,
        read: false,
        createdAt: new Date(),
        tournamentId: formData.target === "tournament" ? formData.tournamentId : undefined,
      }))

      await Promise.all(notifications.map((notification) => addDoc(collection(db, "notifications"), notification)))

      toast.success(`Notification sent to ${targetUsers.length} users`)
      onClose()
    } catch (error) {
      console.error("Error sending notification:", error)
      toast.error("Failed to send notification")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="bg-slate-700/50 border-slate-600">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Send className="mr-2 h-5 w-5" />
          Send Notification
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Notification title"
                className="bg-slate-600 border-slate-500 text-white"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value as any })}>
                <SelectTrigger className="bg-slate-600 border-slate-500 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="info" className="text-white focus:bg-slate-700">
                    Info
                  </SelectItem>
                  <SelectItem value="success" className="text-white focus:bg-slate-700">
                    Success
                  </SelectItem>
                  <SelectItem value="warning" className="text-white focus:bg-slate-700">
                    Warning
                  </SelectItem>
                  <SelectItem value="error" className="text-white focus:bg-slate-700">
                    Error
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300">Message</Label>
            <Textarea
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Notification message"
              className="bg-slate-600 border-slate-500 text-white min-h-[100px]"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Target Audience</Label>
              <Select
                value={formData.target}
                onValueChange={(value) => setFormData({ ...formData, target: value as any, tournamentId: "" })}
              >
                <SelectTrigger className="bg-slate-600 border-slate-500 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="all" className="text-white focus:bg-slate-700">
                    All Users
                  </SelectItem>
                  <SelectItem value="tournament" className="text-white focus:bg-slate-700">
                    Tournament Players
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.target === "tournament" && (
              <div className="space-y-2">
                <Label className="text-gray-300">Tournament</Label>
                <Select
                  value={formData.tournamentId}
                  onValueChange={(value) => setFormData({ ...formData, tournamentId: value })}
                >
                  <SelectTrigger className="bg-slate-600 border-slate-500 text-white">
                    <SelectValue placeholder="Select tournament" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {tournaments.map((tournament) => (
                      <SelectItem key={tournament.id} value={tournament.id} className="text-white focus:bg-slate-700">
                        {tournament.name} ({tournament.registeredPlayers.length} players)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-slate-600 text-gray-300 bg-transparent"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Send className="h-4 w-4 mr-2" />
              {loading ? "Sending..." : "Send Notification"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
