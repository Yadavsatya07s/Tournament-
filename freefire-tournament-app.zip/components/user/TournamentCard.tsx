"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Trophy, Users, Calendar, DollarSign, Clock, MapPin, Key, CreditCard } from "lucide-react"
import { format, formatDistanceToNow, isAfter } from "date-fns"
import CountdownTimer from "./CountdownTimer"
import { useRazorpay } from "@/hooks/useRazorpay"
import type { Tournament } from "@/types"

interface TournamentCardProps {
  tournament: Tournament
  isJoined: boolean
  showRoomDetails?: boolean
}

export default function TournamentCard({ tournament, isJoined, showRoomDetails = false }: TournamentCardProps) {
  const [showDetails, setShowDetails] = useState(false)
  const { processPayment, loading: paymentLoading } = useRazorpay()

  const isFull = tournament.registeredPlayers.length >= tournament.maxPlayers
  const isUpcoming = isAfter(new Date(tournament.date), new Date())
  const canJoin = !isJoined && !isFull && isUpcoming && tournament.status === "upcoming"

  const handleJoinTournament = async () => {
    if (tournament.entryFee === 0) {
      // Free tournament - join directly without payment
      try {
        const response = await fetch("/api/verify-payment", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            razorpay_payment_id: "free_tournament",
            razorpay_order_id: "free_tournament",
            razorpay_signature: "free_tournament",
            tournamentId: tournament.id,
            userId: "current_user_id", // This should be the actual current user ID
            amount: 0,
          }),
        })

        const data = await response.json()
        if (data.success) {
          window.location.reload()
        }
      } catch (error) {
        console.error("Error joining free tournament:", error)
      }
    } else {
      // Paid tournament - process payment
      await processPayment(tournament.id, tournament.entryFee, tournament.name)
    }
  }

  return (
    <>
      <Card className="bg-slate-800/50 border-slate-700 hover:border-purple-500 transition-all duration-300 transform hover:scale-105">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-white text-lg">{tournament.name}</CardTitle>
              <CardDescription className="text-gray-400">
                {format(new Date(tournament.date), "MMM dd, yyyy • HH:mm")}
              </CardDescription>
            </div>
            <Badge
              className={
                tournament.status === "upcoming"
                  ? "bg-blue-600 hover:bg-blue-700"
                  : tournament.status === "ongoing"
                    ? "bg-green-600 hover:bg-green-700"
                    : "bg-gray-600 hover:bg-gray-700"
              }
            >
              {tournament.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Tournament Info */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center text-gray-300">
              <DollarSign className="h-4 w-4 mr-2 text-green-500" />
              Entry: {tournament.entryFee === 0 ? "Free" : `₹${tournament.entryFee}`}
            </div>
            <div className="flex items-center text-gray-300">
              <Trophy className="h-4 w-4 mr-2 text-yellow-500" />
              Prize: ₹{tournament.prizePool.toLocaleString()}
            </div>
            <div className="flex items-center text-gray-300">
              <Users className="h-4 w-4 mr-2 text-blue-500" />
              {tournament.registeredPlayers.length}/{tournament.maxPlayers}
            </div>
            <div className="flex items-center text-gray-300">
              <Clock className="h-4 w-4 mr-2 text-purple-500" />
              {formatDistanceToNow(new Date(tournament.date), { addSuffix: true })}
            </div>
          </div>

          {/* Countdown Timer for upcoming tournaments */}
          {isUpcoming && tournament.status === "upcoming" && (
            <div className="bg-slate-700/50 rounded-lg p-3">
              <CountdownTimer targetDate={new Date(tournament.date)} />
            </div>
          )}

          {/* Room Details for joined tournaments */}
          {isJoined && showRoomDetails && (
            <div className="bg-slate-700/50 rounded-lg p-3 space-y-2">
              <h4 className="text-white font-semibold flex items-center">
                <MapPin className="h-4 w-4 mr-2" />
                Room Details
              </h4>
              <div className="grid grid-cols-1 gap-2 text-sm">
                <div className="flex items-center text-gray-300">
                  <span className="font-medium">Room ID:</span>
                  <span className="ml-2 font-mono bg-slate-600 px-2 py-1 rounded">{tournament.roomId}</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Key className="h-4 w-4 mr-2" />
                  <span className="font-medium">Password:</span>
                  <span className="ml-2 font-mono bg-slate-600 px-2 py-1 rounded">{tournament.roomPassword}</span>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setShowDetails(true)}
              className="flex-1 border-slate-600 text-gray-300 hover:bg-slate-700 bg-transparent"
            >
              View Details
            </Button>
            {canJoin && (
              <Button
                onClick={handleJoinTournament}
                disabled={paymentLoading}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {paymentLoading ? (
                  "Processing..."
                ) : (
                  <>
                    {tournament.entryFee === 0 ? (
                      "Join Free"
                    ) : (
                      <>
                        <CreditCard className="mr-2 h-4 w-4" />
                        Join - ₹{tournament.entryFee}
                      </>
                    )}
                  </>
                )}
              </Button>
            )}
            {isJoined && <Badge className="flex-1 bg-green-600 hover:bg-green-700 justify-center py-2">Joined</Badge>}
            {isFull && !isJoined && (
              <Badge className="flex-1 bg-red-600 hover:bg-red-700 justify-center py-2">Full</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tournament Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white text-2xl">{tournament.name}</DialogTitle>
            <DialogDescription className="text-gray-400">Complete tournament information and details</DialogDescription>
          </DialogHeader>
          <div className="space-y-6">
            {/* Tournament Info Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="text-white font-semibold">Date & Time</h4>
                <p className="text-gray-300 flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  {format(new Date(tournament.date), "EEEE, MMMM dd, yyyy")}
                </p>
                <p className="text-gray-300 flex items-center">
                  <Clock className="h-4 w-4 mr-2" />
                  {format(new Date(tournament.date), "HH:mm")}
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="text-white font-semibold">Prize Information</h4>
                <p className="text-gray-300 flex items-center">
                  <DollarSign className="h-4 w-4 mr-2 text-green-500" />
                  Entry Fee: {tournament.entryFee === 0 ? "Free" : `₹${tournament.entryFee}`}
                </p>
                <p className="text-gray-300 flex items-center">
                  <Trophy className="h-4 w-4 mr-2 text-yellow-500" />
                  Prize Pool: ₹{tournament.prizePool.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Players Info */}
            <div>
              <h4 className="text-white font-semibold mb-2">Players</h4>
              <div className="flex items-center justify-between bg-slate-700/50 rounded-lg p-3">
                <div className="flex items-center text-gray-300">
                  <Users className="h-5 w-5 mr-2 text-blue-500" />
                  <span>
                    {tournament.registeredPlayers.length} / {tournament.maxPlayers} registered
                  </span>
                </div>
                <div className="w-full max-w-xs bg-slate-600 rounded-full h-2 ml-4">
                  <div
                    className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${(tournament.registeredPlayers.length / tournament.maxPlayers) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Room Details (only for joined tournaments) */}
            {isJoined && (
              <div>
                <h4 className="text-white font-semibold mb-2">Room Details</h4>
                <div className="bg-slate-700/50 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Room ID:</span>
                    <span className="font-mono bg-slate-600 px-3 py-1 rounded text-white">{tournament.roomId}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-300">Password:</span>
                    <span className="font-mono bg-slate-600 px-3 py-1 rounded text-white">
                      {tournament.roomPassword}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400 mt-2">
                    Use these details to join the Free Fire room when the tournament starts.
                  </p>
                </div>
              </div>
            )}

            {/* Countdown Timer */}
            {isUpcoming && tournament.status === "upcoming" && (
              <div>
                <h4 className="text-white font-semibold mb-2">Time Remaining</h4>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <CountdownTimer targetDate={new Date(tournament.date)} />
                </div>
              </div>
            )}

            {/* Action Button */}
            <div className="flex justify-end">
              {canJoin && (
                <Button
                  onClick={handleJoinTournament}
                  disabled={paymentLoading}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {paymentLoading ? (
                    "Processing..."
                  ) : tournament.entryFee === 0 ? (
                    "Join Free Tournament"
                  ) : (
                    <>
                      <CreditCard className="mr-2 h-4 w-4" />
                      Join Tournament - ₹{tournament.entryFee}
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
