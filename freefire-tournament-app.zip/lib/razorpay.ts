// Razorpay Configuration
// Replace these placeholder values with your actual Razorpay keys

export const RAZORPAY_CONFIG = {
  key_id: "YOUR_RAZORPAY_KEY_ID_HERE", // Replace with your Razorpay Key ID
  key_secret: "YOUR_RAZORPAY_KEY_SECRET_HERE", // Replace with your Razorpay Key Secret (keep this secure on server)
}

// Load Razorpay script
export const loadRazorpayScript = (): Promise<boolean> => {
  return new Promise((resolve) => {
    const script = document.createElement("script")
    script.src = "https://checkout.razorpay.com/v1/checkout.js"
    script.onload = () => resolve(true)
    script.onerror = () => resolve(false)
    document.body.appendChild(script)
  })
}

// Razorpay payment options interface
export interface RazorpayOptions {
  key: string
  amount: number
  currency: string
  name: string
  description: string
  order_id?: string
  handler: (response: any) => void
  prefill: {
    name: string
    email: string
    contact: string
  }
  theme: {
    color: string
  }
}

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(amount)
}

export const validatePaymentAmount = (amount: number): boolean => {
  return amount > 0 && amount <= 100000 // Max ₹1,00,000
}
