// Firebase Configuration
// Updated with actual Firebase config keys
import { initializeApp, getApp, getApps, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getFirestore, type Firestore } from "firebase/firestore"

// NOTE: Keys provided by user. Do not change without user's instruction.
const firebaseConfig = {
  apiKey: "AIzaSyC6B96Iw1fZYPyR5a2KKyHfBbh7llXNOI0",
  authDomain: "ff-tournament-593a3.firebaseapp.com",
  databaseURL: "https://ff-tournament-593a3-default-rtdb.firebaseio.com",
  projectId: "ff-tournament-593a3",
  storageBucket: "ff-tournament-593a3.appspot.com", // fix bucket host to standard appspot.com
  messagingSenderId: "996246619893",
  appId: "1:996246619893:web:0934c54e5363f585b8e7bc",
  measurementId: "G-92E5PRYWBJ",
}

let _app: FirebaseApp | null = null

function ensureApp(): FirebaseApp {
  if (_app) return _app
  _app = getApps().length ? getApp() : initializeApp(firebaseConfig)
  return _app
}

// Public getters - prefer these everywhere
export function getFirebaseApp(): FirebaseApp {
  return ensureApp()
}

export async function getFirebaseAuth() {
  if (typeof window === "undefined") {
    throw new Error("Firebase Auth is only available on the client")
  }
  const app = ensureApp()
  return getAuth(app)
}

export async function getFirebaseDb() {
  if (typeof window === "undefined") {
    throw new Error("Firebase Firestore is only available on the client")
  }
  const app = ensureApp()
  return getFirestore(app)
}

// Backward-compatible named exports (deprecated).
// They resolve lazily on the client and are not used on the server.
// Prefer calling getFirebaseAuth/getFirebaseDb in components.
export const auth = typeof window !== "undefined" ? getFirebaseAuth() : (null as unknown as Promise<Auth>)
export const db = typeof window !== "undefined" ? getFirebaseDb() : (null as unknown as Promise<Firestore>)

// Default export kept for compatibility with previous imports (not recommended).
export default getFirebaseApp()
