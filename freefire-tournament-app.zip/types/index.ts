// Type definitions for the Free Fire Tournament App

export interface User {
  uid: string
  email: string
  displayName: string
  isAdmin: boolean
  createdAt: Date
  freeFireId?: string
  phoneNumber?: string
}

export interface Tournament {
  id: string
  name: string
  date: Date
  entryFee: number
  maxPlayers: number
  prizePool: number
  roomId: string
  roomPassword: string
  status: "upcoming" | "ongoing" | "completed"
  createdAt: Date
  registeredPlayers: string[] // Array of user UIDs
  results?: TournamentResult[]
}

export interface TournamentResult {
  position: number
  playerName: string
  playerId: string
  prize: number
}

export interface Payment {
  id: string
  userId: string
  tournamentId: string
  amount: number
  status: "pending" | "completed" | "failed"
  razorpayPaymentId?: string
  razorpayOrderId?: string
  createdAt: Date
}

export interface UserTournament {
  tournamentId: string
  userId: string
  paymentId: string
  joinedAt: Date
  status: "registered" | "completed"
}
