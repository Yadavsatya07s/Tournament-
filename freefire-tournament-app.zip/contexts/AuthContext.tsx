"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import type { User as FirebaseUser } from "firebase/auth"
import { getFirebaseAuth, getFirebaseDb } from "@/lib/firebase"
import type { User } from "@/types"
import toast from "react-hot-toast"

interface AuthContextType {
  currentUser: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, displayName: string, freeFireId?: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const login = async (email: string, password: string) => {
    try {
      const auth = await getFirebaseAuth()
      const { signInWithEmailAndPassword } = await import("firebase/auth")
      await signInWithEmailAndPassword(auth, email, password)
      toast.success("Login successful!")
    } catch (error: any) {
      toast.error(error.message)
      throw error
    }
  }

  const register = async (email: string, password: string, displayName: string, freeFireId?: string) => {
    try {
      const auth = await getFirebaseAuth()
      const db = await getFirebaseDb()
      const { createUserWithEmailAndPassword } = await import("firebase/auth")
      const { doc, setDoc, getDoc } = await import("firebase/firestore")
      const { user } = await createUserWithEmailAndPassword(auth, email, password)

      const userData: User = {
        uid: user.uid,
        email: user.email!,
        displayName,
        isAdmin: false,
        createdAt: new Date(),
        freeFireId,
      }

      // ensure we don't overwrite if exists
      const exists = await getDoc(doc(db, "users", user.uid))
      if (!exists.exists()) {
        await setDoc(doc(db, "users", user.uid), userData)
      }
      toast.success("Registration successful!")
    } catch (error: any) {
      toast.error(error.message)
      throw error
    }
  }

  const loginWithGoogle = async () => {
    try {
      const auth = await getFirebaseAuth()
      const db = await getFirebaseDb()
      const { GoogleAuthProvider, signInWithPopup } = await import("firebase/auth")
      const { doc, getDoc, setDoc } = await import("firebase/firestore")
      const provider = new GoogleAuthProvider()
      const { user } = await signInWithPopup(auth, provider)

      const userDoc = await getDoc(doc(db, "users", user.uid))
      if (!userDoc.exists()) {
        const userData: User = {
          uid: user.uid,
          email: user.email!,
          displayName: user.displayName || "User",
          isAdmin: false,
          createdAt: new Date(),
        }
        await setDoc(doc(db, "users", user.uid), userData)
      }

      toast.success("Google login successful!")
    } catch (error: any) {
      toast.error(error.message)
      throw error
    }
  }

  const logout = async () => {
    try {
      const auth = await getFirebaseAuth()
      const { signOut } = await import("firebase/auth")
      await signOut(auth)
      toast.success("Logged out successfully!")
    } catch (error: any) {
      toast.error(error.message)
      throw error
    }
  }

  useEffect(() => {
    let unsubscribe: (() => void) | undefined
    ;(async () => {
      try {
        const auth = await getFirebaseAuth()
        const db = await getFirebaseDb()
        const { onAuthStateChanged } = await import("firebase/auth")
        const { doc, getDoc } = await import("firebase/firestore")

        unsubscribe = onAuthStateChanged(auth, async (firebaseUser: FirebaseUser | null) => {
          if (firebaseUser) {
            const userDoc = await getDoc(doc(db, "users", firebaseUser.uid))
            if (userDoc.exists()) {
              setCurrentUser(userDoc.data() as User)
            } else {
              setCurrentUser({
                uid: firebaseUser.uid,
                email: firebaseUser.email || "",
                displayName: firebaseUser.displayName || "User",
                isAdmin: false,
                createdAt: new Date(),
              })
            }
          } else {
            setCurrentUser(null)
          }
          setLoading(false)
        })
      } catch (e) {
        console.error("[AuthProvider] Failed to subscribe to auth state:", e)
        setLoading(false)
      }
    })()

    return () => {
      if (unsubscribe) unsubscribe()
    }
  }, [])

  const value: AuthContextType = {
    currentUser,
    loading,
    login,
    register,
    loginWithGoogle,
    logout,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
