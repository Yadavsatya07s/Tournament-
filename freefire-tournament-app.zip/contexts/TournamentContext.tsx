"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  where,
  getDocs,
} from "firebase/firestore"
import { db } from "@/lib/firebase"
import type { Tournament, Payment, UserTournament } from "@/types"
import { useAuth } from "./AuthContext"
import toast from "react-hot-toast"

interface TournamentContextType {
  tournaments: Tournament[]
  userTournaments: UserTournament[]
  loading: boolean
  createTournament: (tournament: Omit<Tournament, "id" | "createdAt" | "registeredPlayers">) => Promise<void>
  updateTournament: (id: string, updates: Partial<Tournament>) => Promise<void>
  deleteTournament: (id: string) => Promise<void>
  joinTournament: (tournamentId: string, paymentData: Omit<Payment, "id" | "createdAt">) => Promise<void>
  getUserTournaments: () => void
}

const TournamentContext = createContext<TournamentContextType | undefined>(undefined)

export const useTournaments = () => {
  const context = useContext(TournamentContext)
  if (context === undefined) {
    throw new Error("useTournaments must be used within a TournamentProvider")
  }
  return context
}

export const TournamentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [userTournaments, setUserTournaments] = useState<UserTournament[]>([])
  const [loading, setLoading] = useState(true)
  const { currentUser } = useAuth()

  // Real-time tournaments listener
  useEffect(() => {
    const q = query(collection(db, "tournaments"), orderBy("date", "asc"))
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const tournamentsData: Tournament[] = []
      querySnapshot.forEach((doc) => {
        tournamentsData.push({ id: doc.id, ...doc.data() } as Tournament)
      })
      setTournaments(tournamentsData)
      setLoading(false)
    })

    return unsubscribe
  }, [])

  const createTournament = async (tournamentData: Omit<Tournament, "id" | "createdAt" | "registeredPlayers">) => {
    try {
      await addDoc(collection(db, "tournaments"), {
        ...tournamentData,
        createdAt: new Date(),
        registeredPlayers: [],
      })
      toast.success("Tournament created successfully!")
    } catch (error: any) {
      toast.error("Failed to create tournament")
      throw error
    }
  }

  const updateTournament = async (id: string, updates: Partial<Tournament>) => {
    try {
      await updateDoc(doc(db, "tournaments", id), updates)
      toast.success("Tournament updated successfully!")
    } catch (error: any) {
      toast.error("Failed to update tournament")
      throw error
    }
  }

  const deleteTournament = async (id: string) => {
    try {
      await deleteDoc(doc(db, "tournaments", id))
      toast.success("Tournament deleted successfully!")
    } catch (error: any) {
      toast.error("Failed to delete tournament")
      throw error
    }
  }

  const joinTournament = async (tournamentId: string, paymentData: Omit<Payment, "id" | "createdAt">) => {
    try {
      // Add payment record
      const paymentDoc = await addDoc(collection(db, "payments"), {
        ...paymentData,
        createdAt: new Date(),
      })

      // Add user to tournament's registered players
      const tournamentRef = doc(db, "tournaments", tournamentId)
      const tournament = tournaments.find((t) => t.id === tournamentId)
      if (tournament && currentUser) {
        await updateDoc(tournamentRef, {
          registeredPlayers: [...tournament.registeredPlayers, currentUser.uid],
        })

        // Create user tournament record
        await addDoc(collection(db, "userTournaments"), {
          tournamentId,
          userId: currentUser.uid,
          paymentId: paymentDoc.id,
          joinedAt: new Date(),
          status: "registered",
        })
      }

      toast.success("Successfully joined tournament!")
    } catch (error: any) {
      toast.error("Failed to join tournament")
      throw error
    }
  }

  const getUserTournaments = async () => {
    if (!currentUser) return

    try {
      const q = query(collection(db, "userTournaments"), where("userId", "==", currentUser.uid))
      const querySnapshot = await getDocs(q)
      const userTournamentsData: UserTournament[] = []
      querySnapshot.forEach((doc) => {
        userTournamentsData.push(doc.data() as UserTournament)
      })
      setUserTournaments(userTournamentsData)
    } catch (error: any) {
      toast.error("Failed to fetch user tournaments")
    }
  }

  useEffect(() => {
    if (currentUser) {
      getUserTournaments()
    }
  }, [currentUser])

  const value: TournamentContextType = {
    tournaments,
    userTournaments,
    loading,
    createTournament,
    updateTournament,
    deleteTournament,
    joinTournament,
    getUserTournaments,
  }

  return <TournamentContext.Provider value={value}>{children}</TournamentContext.Provider>
}
