import { type NextRequest, NextResponse } from "next/server"
import { doc, addDoc, collection, updateDoc, arrayUnion } from "firebase/firestore"
import { db } from "@/lib/firebase"

export async function POST(request: NextRequest) {
  try {
    const { razorpay_payment_id, razorpay_order_id, razorpay_signature, tournamentId, userId, amount } =
      await request.json()

    // In a real implementation, you would:
    // 1. Verify the payment signature using Razorpay's webhook signature verification
    // 2. Check if the payment is actually successful with Razorpay's API

    // Mock verification (replace with actual Razorpay verification)
    const isPaymentValid = true // This should be actual verification result

    if (isPaymentValid) {
      // Create payment record
      const paymentData = {
        userId,
        tournamentId,
        amount,
        status: "completed",
        razorpayPaymentId: razorpay_payment_id,
        razorpayOrderId: razorpay_order_id,
        createdAt: new Date(),
      }

      const paymentDoc = await addDoc(collection(db, "payments"), paymentData)

      // Add user to tournament's registered players
      const tournamentRef = doc(db, "tournaments", tournamentId)
      await updateDoc(tournamentRef, {
        registeredPlayers: arrayUnion(userId),
      })

      // Create user tournament record
      await addDoc(collection(db, "userTournaments"), {
        tournamentId,
        userId,
        paymentId: paymentDoc.id,
        joinedAt: new Date(),
        status: "registered",
      })

      return NextResponse.json({
        success: true,
        message: "Payment verified and tournament joined successfully",
      })
    } else {
      // Payment verification failed
      await addDoc(collection(db, "payments"), {
        userId,
        tournamentId,
        amount,
        status: "failed",
        razorpayPaymentId: razorpay_payment_id,
        razorpayOrderId: razorpay_order_id,
        createdAt: new Date(),
      })

      return NextResponse.json(
        {
          success: false,
          error: "Payment verification failed",
        },
        { status: 400 },
      )
    }
  } catch (error) {
    console.error("Error verifying payment:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to verify payment",
      },
      { status: 500 },
    )
  }
}
