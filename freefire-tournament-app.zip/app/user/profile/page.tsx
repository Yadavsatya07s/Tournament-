"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/AuthContext"
import { useTournaments } from "@/contexts/TournamentContext"
import ProtectedRoute from "@/components/ProtectedRoute"
import Navbar from "@/components/Navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { User, Trophy, Edit, Save, X } from "lucide-react"
import { format } from "date-fns"

export default function UserProfile() {
  const { currentUser } = useAuth()
  const { tournaments, userTournaments } = useTournaments()
  const [isEditing, setIsEditing] = useState(false)
  const [editData, setEditData] = useState({
    displayName: currentUser?.displayName || "",
    freeFireId: currentUser?.freeFireId || "",
  })

  // Get user's tournament history
  const userTournamentHistory = userTournaments
    .map((ut) => {
      const tournament = tournaments.find((t) => t.id === ut.tournamentId)
      return { ...ut, tournament }
    })
    .filter((ut) => ut.tournament)

  const completedTournaments = userTournamentHistory.filter((ut) => ut.tournament?.status === "completed")
  const upcomingTournaments = userTournamentHistory.filter((ut) => ut.tournament?.status === "upcoming")

  const handleSave = () => {
    // This would update the user profile in Firebase
    console.log("Save profile:", editData)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditData({
      displayName: currentUser?.displayName || "",
      freeFireId: currentUser?.freeFireId || "",
    })
    setIsEditing(false)
  }

  if (!currentUser) return null

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              My Profile
            </h1>
            <p className="text-gray-400 mt-2">Manage your account and view tournament history</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Profile Information */}
            <div className="lg:col-span-1">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white flex items-center">
                      <User className="mr-2 h-5 w-5" />
                      Profile Information
                    </CardTitle>
                    {!isEditing ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setIsEditing(true)}
                        className="border-slate-600 text-gray-300 hover:bg-slate-700 bg-transparent"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    ) : (
                      <div className="flex gap-2">
                        <Button size="sm" onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                          <Save className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleCancel}
                          className="border-slate-600 text-gray-300 hover:bg-slate-700 bg-transparent"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-gray-300">Display Name</Label>
                    {isEditing ? (
                      <Input
                        value={editData.displayName}
                        onChange={(e) => setEditData({ ...editData, displayName: e.target.value })}
                        className="bg-slate-700/50 border-slate-600 text-white"
                      />
                    ) : (
                      <p className="text-white">{currentUser.displayName}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-gray-300">Email</Label>
                    <p className="text-white">{currentUser.email}</p>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-gray-300">Free Fire ID</Label>
                    {isEditing ? (
                      <Input
                        value={editData.freeFireId}
                        onChange={(e) => setEditData({ ...editData, freeFireId: e.target.value })}
                        className="bg-slate-700/50 border-slate-600 text-white"
                        placeholder="Enter your Free Fire ID"
                      />
                    ) : (
                      <p className="text-white">{currentUser.freeFireId || "Not provided"}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-gray-300">Member Since</Label>
                    <p className="text-white">{format(new Date(currentUser.createdAt), "MMMM dd, yyyy")}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Stats Card */}
              <Card className="bg-slate-800/50 border-slate-700 mt-6">
                <CardHeader>
                  <CardTitle className="text-white">Tournament Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Total Tournaments</span>
                    <Badge className="bg-blue-600">{userTournamentHistory.length}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Completed</span>
                    <Badge className="bg-green-600">{completedTournaments.length}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Upcoming</span>
                    <Badge className="bg-yellow-600">{upcomingTournaments.length}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Total Winnings</span>
                    <Badge className="bg-purple-600">₹0</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Tournament History */}
            <div className="lg:col-span-2">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Trophy className="mr-2 h-5 w-5" />
                    Tournament History
                  </CardTitle>
                  <CardDescription className="text-gray-400">
                    Your participation history in Free Fire tournaments
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {userTournamentHistory.length === 0 ? (
                    <div className="text-center py-8 text-gray-400">
                      <Trophy className="mx-auto h-12 w-12 mb-4 opacity-50" />
                      <p>No tournament history yet. Join your first tournament!</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow className="border-slate-700">
                          <TableHead className="text-gray-300">Tournament</TableHead>
                          <TableHead className="text-gray-300">Date</TableHead>
                          <TableHead className="text-gray-300">Entry Fee</TableHead>
                          <TableHead className="text-gray-300">Status</TableHead>
                          <TableHead className="text-gray-300">Result</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {userTournamentHistory.map((ut) => (
                          <TableRow key={ut.tournamentId} className="border-slate-700">
                            <TableCell className="text-white font-medium">{ut.tournament?.name}</TableCell>
                            <TableCell className="text-gray-300">
                              {ut.tournament && format(new Date(ut.tournament.date), "MMM dd, yyyy")}
                            </TableCell>
                            <TableCell className="text-gray-300">₹{ut.tournament?.entryFee}</TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  ut.tournament?.status === "upcoming"
                                    ? "bg-blue-600"
                                    : ut.tournament?.status === "ongoing"
                                      ? "bg-green-600"
                                      : "bg-gray-600"
                                }
                              >
                                {ut.tournament?.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-gray-300">
                              {ut.tournament?.status === "completed" ? "Participated" : "-"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
