"use client"

import { useState, useMemo } from "react"
import { useTournaments } from "@/contexts/TournamentContext"
import { useAuth } from "@/contexts/AuthContext"
import ProtectedRoute from "@/components/ProtectedRoute"
import Navbar from "@/components/Navbar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trophy, Calendar, Users, DollarSign, Filter, Search } from "lucide-react"
import { isAfter, isBefore, addDays } from "date-fns"
import TournamentCard from "@/components/user/TournamentCard"

export default function UserDashboard() {
  const { tournaments, userTournaments, loading } = useTournaments()
  const { currentUser } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("all")
  const [feeFilter, setFeeFilter] = useState("all")

  // Filter tournaments based on search and filters
  const filteredTournaments = useMemo(() => {
    let filtered = tournaments.filter((tournament) => tournament.status === "upcoming")

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter((tournament) => tournament.name.toLowerCase().includes(searchTerm.toLowerCase()))
    }

    // Date filter
    if (dateFilter !== "all") {
      const now = new Date()
      switch (dateFilter) {
        case "today":
          filtered = filtered.filter((tournament) => {
            const tournamentDate = new Date(tournament.date)
            return tournamentDate.toDateString() === now.toDateString()
          })
          break
        case "week":
          const weekFromNow = addDays(now, 7)
          filtered = filtered.filter((tournament) => {
            const tournamentDate = new Date(tournament.date)
            return isAfter(tournamentDate, now) && isBefore(tournamentDate, weekFromNow)
          })
          break
        case "month":
          const monthFromNow = addDays(now, 30)
          filtered = filtered.filter((tournament) => {
            const tournamentDate = new Date(tournament.date)
            return isAfter(tournamentDate, now) && isBefore(tournamentDate, monthFromNow)
          })
          break
      }
    }

    // Fee filter
    if (feeFilter !== "all") {
      switch (feeFilter) {
        case "free":
          filtered = filtered.filter((tournament) => tournament.entryFee === 0)
          break
        case "low":
          filtered = filtered.filter((tournament) => tournament.entryFee > 0 && tournament.entryFee <= 50)
          break
        case "medium":
          filtered = filtered.filter((tournament) => tournament.entryFee > 50 && tournament.entryFee <= 200)
          break
        case "high":
          filtered = filtered.filter((tournament) => tournament.entryFee > 200)
          break
      }
    }

    return filtered
  }, [tournaments, searchTerm, dateFilter, feeFilter])

  // Get user's joined tournaments
  const joinedTournamentIds = userTournaments.map((ut) => ut.tournamentId)
  const joinedTournaments = tournaments.filter((t) => joinedTournamentIds.includes(t.id))

  // Stats
  const upcomingCount = tournaments.filter((t) => t.status === "upcoming").length
  const joinedCount = joinedTournaments.length
  const completedCount = tournaments.filter((t) => t.status === "completed").length

  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              Tournament Arena
            </h1>
            <p className="text-gray-400 mt-2">Join exciting Free Fire tournaments and compete for amazing prizes!</p>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Available Tournaments</CardTitle>
                <Trophy className="h-4 w-4 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{upcomingCount}</div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Joined Tournaments</CardTitle>
                <Users className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{joinedCount}</div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Completed</CardTitle>
                <Calendar className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{completedCount}</div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-400">Total Winnings</CardTitle>
                <DollarSign className="h-4 w-4 text-purple-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">₹0</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="bg-slate-800/50 border-slate-700 mb-8">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Filter className="mr-2 h-5 w-5" />
                Filter Tournaments
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search tournaments..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>

                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Filter by date" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="all" className="text-white focus:bg-slate-700">
                      All Dates
                    </SelectItem>
                    <SelectItem value="today" className="text-white focus:bg-slate-700">
                      Today
                    </SelectItem>
                    <SelectItem value="week" className="text-white focus:bg-slate-700">
                      This Week
                    </SelectItem>
                    <SelectItem value="month" className="text-white focus:bg-slate-700">
                      This Month
                    </SelectItem>
                  </SelectContent>
                </Select>

                <Select value={feeFilter} onValueChange={setFeeFilter}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Filter by entry fee" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="all" className="text-white focus:bg-slate-700">
                      All Entry Fees
                    </SelectItem>
                    <SelectItem value="free" className="text-white focus:bg-slate-700">
                      Free (₹0)
                    </SelectItem>
                    <SelectItem value="low" className="text-white focus:bg-slate-700">
                      Low (₹1-50)
                    </SelectItem>
                    <SelectItem value="medium" className="text-white focus:bg-slate-700">
                      Medium (₹51-200)
                    </SelectItem>
                    <SelectItem value="high" className="text-white focus:bg-slate-700">
                      High (₹200+)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Tournaments Grid */}
          <div className="space-y-8">
            {/* Available Tournaments */}
            <div>
              <h2 className="text-2xl font-bold text-white mb-6">Available Tournaments</h2>
              {loading ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
                </div>
              ) : filteredTournaments.length === 0 ? (
                <Card className="bg-slate-800/50 border-slate-700">
                  <CardContent className="text-center py-8">
                    <Trophy className="mx-auto h-12 w-12 mb-4 text-gray-500" />
                    <p className="text-gray-400">No tournaments found matching your criteria.</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredTournaments.map((tournament) => (
                    <TournamentCard
                      key={tournament.id}
                      tournament={tournament}
                      isJoined={joinedTournamentIds.includes(tournament.id)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Joined Tournaments */}
            {joinedTournaments.length > 0 && (
              <div>
                <h2 className="text-2xl font-bold text-white mb-6">My Tournaments</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {joinedTournaments.map((tournament) => (
                    <TournamentCard
                      key={tournament.id}
                      tournament={tournament}
                      isJoined={true}
                      showRoomDetails={true}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </ProtectedRoute>
  )
}
