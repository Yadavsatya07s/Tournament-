# Free Fire Tournament App

A comprehensive React.js application for managing Free Fire tournaments with Firebase backend and Razorpay payment integration.

## Features

### User Features
- **Authentication**: Email/password and Google sign-in
- **Tournament Discovery**: Browse and filter upcoming tournaments
- **Payment Integration**: Secure payments via Razorpay
- **Real-time Updates**: Live tournament data and notifications
- **Tournament Participation**: Join tournaments and view room details
- **Profile Management**: Track tournament history and winnings
- **Countdown Timers**: Real-time countdown for upcoming tournaments

### Admin Features
- **Tournament Management**: Create, edit, and delete tournaments
- **Player Management**: View registered players for each tournament
- **Results Management**: Add tournament results and prize distribution
- **Notification System**: Send notifications to all users or specific tournament participants
- **Dashboard Analytics**: View tournament statistics and metrics
- **Real-time Monitoring**: Live updates on tournament registrations

### Technical Features
- **Firebase Integration**: Authentication, Firestore database, real-time updates
- **Razorpay Integration**: Secure payment processing
- **Responsive Design**: Mobile-first approach with dark theme
- **Real-time Notifications**: In-app notification system
- **Type Safety**: Full TypeScript implementation
- **Modern UI**: shadcn/ui components with Tailwind CSS

## Installation & Setup

### Prerequisites
- Node.js 18+ and npm
- Firebase project
- Razorpay account

### 1. Clone and Install
\`\`\`bash
git clone <repository-url>
cd freefire-tournament-app
npm install
\`\`\`

### 2. Firebase Setup
1. Create a Firebase project at https://console.firebase.google.com
2. Enable Authentication (Email/Password and Google)
3. Create Firestore database
4. Replace placeholders in `lib/firebase.ts` with your config:

\`\`\`javascript
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-auth-domain",
  projectId: "your-project-id",
  storageBucket: "your-storage-bucket",
  messagingSenderId: "your-messaging-sender-id",
  appId: "your-app-id",
}
\`\`\`

### 3. Razorpay Setup
1. Create account at https://razorpay.com
2. Get your API keys from dashboard
3. Replace placeholders in `lib/razorpay.ts`:

\`\`\`javascript
export const RAZORPAY_CONFIG = {
  key_id: "your-razorpay-key-id",
  key_secret: "your-razorpay-key-secret", // Server-side only
}
\`\`\`

### 4. Firestore Security Rules
\`\`\`javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Tournaments are readable by all, writable by admins
    match /tournaments/{tournamentId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
    
    // Payments are readable by owner, writable by system
    match /payments/{paymentId} {
      allow read: if request.auth != null && request.auth.uid == resource.data.userId;
      allow write: if request.auth != null;
    }
    
    // User tournaments are readable by owner
    match /userTournaments/{docId} {
      allow read: if request.auth != null && request.auth.uid == resource.data.userId;
      allow write: if request.auth != null;
    }
    
    // Notifications are readable by recipient
    match /notifications/{notificationId} {
      allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }
  }
}
\`\`\`

### 5. Run the Application
\`\`\`bash
npm run dev
\`\`\`

Visit http://localhost:3000

## Project Structure

\`\`\`
├── app/
│   ├── admin/              # Admin panel pages
│   ├── auth/               # Authentication pages
│   ├── user/               # User panel pages
│   └── api/                # API routes for payments
├── components/
│   ├── admin/              # Admin-specific components
│   ├── user/               # User-specific components
│   └── ui/                 # Reusable UI components
├── contexts/               # React contexts for state management
├── hooks/                  # Custom React hooks
├── lib/                    # Utility libraries and configurations
└── types/                  # TypeScript type definitions
\`\`\`

## Usage

### For Users
1. Register/Login to your account
2. Browse available tournaments
3. Filter by date, entry fee, etc.
4. Join tournaments via secure payment
5. View room details after registration
6. Track your tournament history

### For Admins
1. Login with admin account
2. Create and manage tournaments
3. View registered players
4. Send notifications to users
5. Add tournament results
6. Monitor platform analytics

## Environment Variables

Create `.env.local` file:
\`\`\`
NEXT_PUBLIC_FIREBASE_API_KEY=your-firebase-api-key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-firebase-auth-domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-firebase-project-id
RAZORPAY_KEY_SECRET=your-razorpay-secret-key
\`\`\`

## Deployment

### Vercel (Recommended)
1. Push code to GitHub
2. Connect repository to Vercel
3. Add environment variables
4. Deploy

### Firebase Hosting
\`\`\`bash
npm run build
firebase deploy
\`\`\`

## Support

For issues and support:
1. Check Firebase console for authentication/database errors
2. Verify Razorpay integration in test mode first
3. Ensure all environment variables are set correctly
4. Check browser console for client-side errors

## License

This project is licensed under the MIT License.
